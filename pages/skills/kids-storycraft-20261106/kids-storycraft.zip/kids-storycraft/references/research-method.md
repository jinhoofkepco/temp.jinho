# Close reading and source discovery

Prefer authorized full texts, publisher previews, creator/editor materials, and official educational resources. A famous title or a synopsis is a source candidate, not evidence that its wording, images, ending, or timing has been analyzed. Use [English source study](english-source-study.md) as a starting pool, not an exhaustive reading list.

## State what was actually inspected

Record title/creator, direct link, medium, exact available scope, a useful location, observed mechanism, proposed adaptation, and what remains unknown. Distinguish:

- Complete story text from a complete book or magazine issue.
- Selected preview spreads from consecutive complete pages.
- Actual pixels from alt text, OCR, and a product description.
- A creator's explanation from an editor's opinion or the analyst's inference.
- A production storyboard/layout from a released film.
- A full or excerpted official script from subtitles, fan transcription, or republished text.
- Continuous viewing from sampled frames. Frame sampling does not establish exact cuts, short gestures, music, or audience laughter.

When PDF extraction combines main prose, a running mascot comic, page numbers, and captions, separate the reading streams. Do not turn sidebar banter into the protagonist's speech or mistake a teacher guide for the story itself. The SPIDER sample in the English study makes this distinction necessary.

For TV, identify by title and source as well as episode number; regional packaging can combine stories differently. Specify whether a timestamp belongs to the whole subtitle file, an excerpt, or a production video. Do not estimate screen time from dialogue length.

## Connect observation to a usable decision

At a meaningful beat, identify goal, obstacle/cost, attempt, consequence, changed information or relationship, reader expectation, humor's function, and final payoff. Fill only fields supported by the source. A scene boundary is not automatically a story turn.

At sentence/word level, inspect viewpoint and evaluative words, action and direction, reference, repeated structure, time/aspect, sound or stress, and disclosure order. Compare deletion, neutralization, and relocation. A useful detail may create orientation or time rather than foreshadowing.

For images, point to contact, state, gaze, body, position, scale, and exposure order. A shot label or emotion name does not prove the delivered effect. A textual transcript can support a speech pattern without supporting a claim about exact facial acting.

Describe the mechanism without names, then test a new desire, prop, event, and ending. Keep the source observation, cross-source inference, and new example distinguishable. Do not call the resulting guideline a creator's formula unless the creator actually said it.

## Keep claims proportional

Retain concise analysis cards and links, not whole source books, video frames, subtitles, or transcripts in a shared skill. Use only short necessary quotations. Public access is not a blanket reuse license; genuinely open material still has attribution conditions. Do not purchase, subscribe, submit, or message anyone just to extend an analysis task.

Popularity, awards, adult reviews, word counts, and a formally valid skill do not establish enjoyment or comprehension by this user's child. Record the actual feedback separately. If exact visual or vocal delivery matters but the available source does not establish it, inspect the relevant segment or preserve that uncertainty.
