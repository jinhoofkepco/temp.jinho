# Comics, companion prose, crops, and reading artifacts

Use only the requested output mode. A new comic requires the actual art and story when requested; a request for image prompts requires prompts. Cutting an existing comic means reusing its existing images. Do not regenerate the art merely to separate panels.

For one-take production, plan the reader and crop needs before generation, save and assemble the first outputs, and retain [production records](production-records.md). The inspection and repair procedures in this reference apply when review or revision is requested. Saving, cropping and linking the planned outputs do not authorize alternate image generations.

## Plan the two channels together

At important turns, align `story meaning / visible evidence / what English prose adds / next change`. The image can carry posture, gaze, contact, object state, and a visual clue. The prose can carry motive, time, a brief thought, or voice. It should read as a connected story, not just a transcription of every balloon.

Keep fact, interpretation, and reader knowledge aligned across both channels. A hidden foot must really be visible if the reader is meant to infer it. Do not name the source in the paragraph before the panel meant to reveal it. Selective overlap helps some beginner readers; see [audience and language](audience-and-language.md).

Cropped panels beside English prose are a useful format for an HTML reader when requested. Do not automatically add a PDF. Choose panel count for meaningful transitions, not a permanent eight- or ten-panel template.

## Freeze a final source before making derivatives

Keep the original pages and crop along their actual boundaries. Uneven layouts need uneven crop boxes. Preserve important fingers, feet, lettering, and clues; do not assume a uniform grid. If a source page changes, recrop its affected panels and update external files, inline images, and offline readers.

When generating new art for a user-specified fixed grid, establish the requested crop geometry before generation and place essential information inside the retained area. Existing uneven pages still follow their actual boundaries. Do not make the old experiment's 10% inset a universal setting. Preserve the full first sheet and crop mapping so later review can distinguish an original framing issue from a clue lost during cutting.

Where provenance helps, maintain a simple crop manifest: source name or hash, panel number, box, and result dimensions. Pixel comparison can prove that a cut uses the same source; it cannot establish whether a clue or a balloon remains readable. A tiny one-panel job does not need a large manifest system.

Use matching panel numbers, prose paragraphs, navigation order and original-page references during assembly. If several copies of the prose exist, retain the intended first-delivery version and its mapping. Do not silently rewrite the story to excuse an art error. Under one-take production, preserve the first outputs for later user-requested review; when repair is requested, address the meaningful discrepancy.

## Build for actual reading

Design side-by-side art and prose to stack naturally on small screens. Preserve the art's aspect ratio and allocate enough size for hands, faces and clues from the start. Desktop/phone output inspection belongs to a requested reader review; it is not a standing content-QA loop for one-take delivery.

Offer sequential or continuous reading when exposure order matters. Pictures-only view can support visual reading or a requested diagnosis. These are task-dependent features, not a compulsory interface package. Keep the planned scene number, media and navigation tied to the same scene IDs. Required software checks for newly written control logic are distinct from content inspection; do not use them to start story/art scoring or regeneration.

Keep production commentary outside the child-facing prose: a separate file or a folded optional area can work. An interface cannot supply an absent cause or reaction.

## Offline and online versions

If an offline ZIP is requested, include images in the HTML or supply relative paths inside the package; do not depend on a localhost server or private working-directory path. Build the online and offline versions from the same scene/prose mapping. Extraction and opening for inspection belong to a requested package check; the first-take archive retains the original package and its source mapping.

For a public story package, include the reader, needed art, story text, and brief use instructions. Whole working folders can accidentally contain user feedback, local paths, skills, research notes, prompts, or third-party excerpts. Keep an intentionally shared skill package separate from the story download. Source study is not permission to republish a source video, book image, or transcript.

External image assets can avoid inline duplication online; a self-contained HTML file can be convenient offline. Count the full deployment, including crops, original pages, ZIPs, and pre-existing files. Confirm the hosting service's actual limits rather than hardcoding a limit from an earlier job. Preserve existing required files when reducing duplication. If full original pages are available only in the ZIP, make the reader's link describe that download accurately.

Use the relevant site service workflow only when publication is requested, preserve the selected site and audience, and finish the actual deployment. A local artifact request is not a standing publication instruction.

Follow the destination's repository and catalog workflow. Use its supported index generator when applicable. Record the local artifact path and verify the deployed page after publication.

## Output at the requested scale

For an episode, provide the desired outline or finished scenes/dialogue, not an outline when a finished script was requested. Establish goal, obstacle, attempts, changing conditions, crisis/resolution, and the particular roles of humor or discovery.

For one or two scenes, give a short setup, one drawable instant per scene, the visible clue, natural attributed dialogue, and the next change where useful. Do not compress a whole episode's action into a single frame. For prose alone, deliver the story without a panel-design table unless asked for one.
