# Different story modes with the same quality standard

Use for several contrasting stories or a change of style. Change the reader's question, information order, choices, and ending before changing the palette or setting. These are useful modes from the user's project, not a complete genre system.

| Design | Mystery / discovery | Physical comedy | Quiet adventure / wonder |
|---|---|---|---|
| Reader's question | What actually happened? | Can the character control the approaching mishap? | What have we failed to notice? |
| Information | Observations first; competing interpretations remain possible | Reader sees the irritant or risk before the character can contain it | A familiar method misses a small signal |
| Changed condition | Comparing evidence narrows the explanations | Pride or another trait makes the attempted fix unstable | Stopping or changing the method makes discovery possible |
| Visual peak | Separate a clue insert from the larger identity reveal | Contact → held effort → release → aftermath | A deliberate adjustment → stillness → a wider discovery |
| Prose job | Distinguish a fact from the character's guess | Voice, repeated pressure, or a deadline shapes anticipation | Attend to a small signal without naming the whole discovery early |
| Ending | The same object or label means something different | The setup returns with another person or condition | The goal or direction of help changes |

The same standards of causality, acting, and earned emphasis apply. Quiet does not mean uneventful; comedy does not require constant shouting. Not every mystery needs a twist, and not every quiet story should switch a lamp off.

## Worked cases from the user's original comics

**The Snowman's Secret / 눈사람의 비밀 — eight panels.** A snowman and its apparent stone support disappear. Footprints, a sound, and a foot pressing the snow precede the tortoise reveal. The initial “rock” is an interpretation rather than proof of magic. “Even the rock was gone” expands what must be explained; “Not our boots” leaves a comparison rather than an answer. The final “driver” gives the support a new role. A clue must survive lighting, panel size, and cropping.

**A Very Serious Picture / 아주 진지한 사진 — ten panels.** A character wants a dignified portrait, keeps the feathered hat, and tries to manage the tickle while a timer runs. The choice to preserve appearances keeps the cause active. The tall hat/higher chin opening connects pride to bodily direction. Countdown, feather contact, sneeze/flash, printed result, and a new tickled nose have different functions. The ending repeats a prepared cause rather than adding a moral.

**When the Lantern Went Out / 등불이 꺼진 뒤 — ten panels.** A bright search circle excludes a faint signal. The character notices the edge, presses the switch, waits, and discovers a larger field of lights. “One blink. Then another” leaves time for recognition; the final guiding role changes. Dark pictures still need readable signals and gaze. Do not announce the meadow's answer in the setup paragraph.

These are the writer's original applications, created on 2026-11-02. The three stories have not received individual quality scores. The user's praise of the preceding cake-cart story is not a test result for these modes.

## Additional choices from the homage experiment

The user said the five classic-inspired stories were much better, while still finding their pictures too similar. That is feedback on the batch, not an isolated test of these mechanisms or of this later merged skill. Useful initial-design choices include:

- A strange rule makes a successful adjustment create a new difficulty; learning the rule changes the order of actions, as in the Alice-inspired size-and-key problem.
- Someone who dismissed a small helper becomes dependent on that helper; the original help and later reciprocal action prepare the relationship reversal, as in the lion and mouse.
- Repeated failures collect previously separated participants into a shared action, as in the three pigs. Greater numbers and effective cooperation are distinct ideas.
- A return journey passes through changing spaces and a failed expectation of outside help, as in the Oz-inspired story. An established resource makes the return possible.

Use the mechanism that fits the requested story or word; do not require classical homage, eight panels or all of these choices in each batch.

## Differentiate a group while planning

Before generating a group, choose its different questions, attempts, decisive changes and endings together. Change a repeated information relation or resolution mechanism while writing the plan rather than relying on palette changes. If a series is intentionally formulaic, preserve its recognizable frame and vary the meaningful problem within it. Comparing completed works is reserved for a user-requested review.
