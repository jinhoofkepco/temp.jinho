# One-take production records

Use for each produced work so the user can request a later batch review. Recording is part of saving the work, not an assessment or a reason to generate alternatives. The one-take default and the user's control over later review are in [SKILL.md](../SKILL.md).

## Capture what was actually used

- Assign a stable work ID and timestamp. Save the user's original request and supplied audience, language, format, target word and selected sense. Leave unspecified conditions unknown rather than inventing a profile.
- Snapshot the actual skill and reference files read for this work, preserving their relative names and SHA-256 hashes. Capture them when read, before generation, rather than copying a newer skill during later review. Do not snapshot the entire skill catalog.
- Save an existing outline, explicit scene plan, final story and relevant user overrides. Do not create a new analysis to fill the log, reconstruct hidden reasoning, or write a retrospective explanation of why the work succeeded or failed.
- For each real generation call, retain its exact submitted prompt/input file, supplied parameters, reference-image IDs or saved paths, tool and exposed model information, scene/page coverage, start/end timestamps, returned file IDs and factual error/status. Keep requested and reported model fields distinct; use null when the tool does not expose a value. Record caller wall time as wall time, not GPU time. Do not include authentication headers, keys or unrelated session logs.
- Preserve the first returned images, text and audio as immutable local originals. Map each delivered scene to its source output; for a crop, retain source ID, coordinates and result file. Keep reference inputs retrievable through a stable permitted copy or existing archive reference, with a hash. A path to an ephemeral generated-image directory alone is not a durable record.
- Leave feedback and review arrays empty until actual user feedback or a requested review exists. Record feedback verbatim with work/scene IDs and date. Do not add automatic quality scores, pass/fail labels, predicted child reactions or inferred reasons.

Use information already present in the task and tool responses. Saving/copying files and computing hashes do not require another model call. If an earlier input, tool setting or original is unavailable, mark it missing; do not fabricate it or regenerate it to complete the archive.

## Keep a small private work folder

Use the project's established private record location. Otherwise use `work/kids-storycraft-records/<work-id>/` inside the current workspace, outside web roots and story downloads. Put `record.json`, instruction snapshots, exact input files and first-output copies there. A small text-only work can use just its saved text, instruction snapshots and record; do not add an HTML reader, ZIP or image merely for logging.

At the record root, maintain a factual `index.jsonl` with work ID, title, created time and relative record path. This makes a user-selected group of 10 or 20 works easy to retrieve; the count never starts a review automatically. Do not publish or attach the private archive to a public story package by default.

The following illustrates field relationships, not mandatory invented values:

```json
{
  "schema_version": 1,
  "work_id": "work-id",
  "created_at": "ISO-8601 timestamp with offset",
  "request": {
    "text_file": "request.txt",
    "audience": null,
    "language": "English",
    "format": "comic",
    "target_word": null,
    "selected_sense": null
  },
  "instructions": [
    {"source": "kids-storycraft/SKILL.md", "snapshot": "instructions/SKILL.md", "sha256": "actual file hash"}
  ],
  "design": {"existing_plan_file": null, "first_story_file": "first/story.txt"},
  "calls": [
    {
      "call_id": "image-01",
      "scene_ids": [1, 2, 3, 4],
      "tool": "actual tool name",
      "model_requested": null,
      "model_reported": null,
      "prompt_file": "inputs/image-01.txt",
      "parameters_file": "inputs/image-01.json",
      "reference_ids": [],
      "started_at": null,
      "completed_at": null,
      "wall_seconds": null,
      "status": "returned",
      "error": null
    }
  ],
  "artifacts": [
    {"id": "sheet-01", "kind": "image_original", "path": "first/sheet-01.png", "sha256": "actual file hash", "from_call": "image-01"},
    {"id": "scene-01", "kind": "crop", "path": "first/scene-01.png", "sha256": "actual file hash", "scene_ids": [1], "derived_from": "sheet-01", "crop_box": [0, 0, 100, 100]}
  ],
  "feedback": [],
  "reviews": []
}
```

Use the real IDs, paths and crop boxes; sample coordinates and hashes are not defaults. `status` describes whether a call returned, failed or was interrupted, not the quality of its result. Audio and companion prose use the same scene IDs as their pictures.

## When the user later requests a review

Review the selected immutable first takes alongside their captured instructions and actual prompts. Distinguish a missing design instruction, an instruction omitted from the submitted prompt, a generated result that differs from the prompt, and a derivative/reader assembly issue. Allow uncertainty about causes. Link dated findings and any supplied scores back to the exact works and scenes, preserving the original records.

Apply authorized lessons to the skill for subsequent work. A batch-review request does not itself request repairs to every old work or establish that a rule improved child comprehension. Any later revised outputs belong in a separate version linked to the first take.
