# Thumbnails, framing, and continuity

Use while designing the first comic or storyboard, and when a review is explicitly requested. Identify the evidence needed for [visual causality](visual-causality.md), [emotion](emotion-acting.md), and [dramatic emphasis](dramatic-emphasis.md) before generating art. Camera variety is a means to those ends. Output inspection below belongs to requested review, not an automatic one-take stage.

## Distinguish the working tools

- An outline sets events, choices, and turns.
- A shot list assigns what to show and from where.
- A thumbnail tests figures, objects, space, and attention cheaply; it is not polished illustration.
- A storyboard refines action, expression, framing, and sequence.
- A blocking diagram or plan view resolves difficult positions and camera axes when necessary.
- An animatic adds timed playback and possibly sound; still panels alone are not an animatic.

Do not attach camera directions to ordinary prose unless they help the requested task. For an actual comic, keep production notes separate from the child's story.

## Choose the screen function

Plan the sequence's major shifts before writing isolated image prompts. A short note per useful beat is enough: `what changes / viewer position and first focus / connection or contrast with neighbors`. Decide whose access to the event matters: an outside view can establish geography, while a character's view can let the reader discover or wait with them. A route, a hidden object, a face and a changed relationship have different first focuses. Do not give every scene the same centered cast, object and richly filled background with a different camera label.

Start from what the reader must notice first and what changes now. Shot size and angle describe different properties. Wide/medium/close describes included space; high/low/eye-level describes a viewing position; over-the-shoulder is a framing relation; POV is a character's viewpoint; an insert isolates a useful detail.

| Candidate | Useful function | Common loss |
|---|---|---|
| Wide / establishing | Route, relative distance, arrival, scale | Contact or face becomes too small |
| Medium / two-shot | Whole-body attitude and relationship | Repeated frontal waist-up staging |
| Close reaction | Recognition, listening, hesitation | What caused the reaction disappears |
| Insert | Valve, foot, mark, knot, switch | The acting hand or object loses identity |
| Over-the-shoulder | What someone addresses, sees, or conceals | Foreground shoulder hides the decisive evidence |
| POV | Discovery in the character's order | A guess is presented as objective fact |
| High / top-down | Object arrangement and paths | Expressions become illegible |
| Low / large foreground | Approaching size, pressure, distance | Exaggeration changes count or force direction |
| Rear / doorway frame | Departing, hiding, seeing beyond | Position or gaze becomes ambiguous |

High does not always mean weak and low does not always mean strong. “Cinematic” does not require a tilted horizon. Give the reference prompt separate instructions for the character/prop design to retain and the camera to redesign; otherwise the old composition can be copied along with the character.

## Commit the camera in the submitted prompt

Convert the chosen view into drawable spatial facts before generation. Use the existing scene notes; this is prompt preparation, not an additional rendering or output-review pass.

- **Position and direction:** place the camera relative to a person or landmark and say where it looks. For a wagon-level view, put it near the axle looking along the path; for an overhead route, show the layout from above. A diagonal horizon alone does not establish a low camera.
- **Frame boundaries and first focus:** name what dominates the image and where bodies or objects leave the frame. A face close-up can cut off the torso; an insert can contain only a cuff, fingers and a knot. Choose enough evidence to identify the action without restoring every full figure.
- **Visible cast and context:** the shared cast description establishes identity, not attendance. Name the visible subset for each panel. Leave other faces, props and scenery offscreen, distant or subordinate as appropriate. Re-establish them in a neighboring view when needed.
- **Conflicting demands:** when a tight view also asks for the entire object, all participants and the surroundings, choose which information belongs here. Move context to a neighboring scene or deliberately choose a wider view. Do not keep the close-up label while filling the frame with unrelated context.

A compact prompt can follow: `instant and first focus → camera position and viewing direction → frame boundaries → necessary identity, contact and state → offscreen or background limits`. Lead with the event; the camera serves that event. Omit fields that add nothing. A fixed warm grade or a full decorative background in every panel can flatten the intended changes in space and attention.

Carry the outline's disclosure order into the prompt. Put stable character and prop designs in shared context. Put ownership, positions, transformations and first appearances in the relevant panel instructions. Before a reveal, specify a concrete occluder, a cropped frame or another visible subset. For example, show a box seam and wings pressing hats in before the next view first reveals the bell on a duck's head. A future costume or prop state in shared context can appear early even when the scene plan assigns it to a later cut.

When a turn depends on a comparison, include the evidence that makes it readable. Compare heights with visible tops and a common baseline. Match the viewpoint across two panels when the changed object or expression is the point. Change the viewpoint when the new position discloses a route, obstruction, hidden action or reaction that the previous frame could not show.

For example, a rigging insert can show two paws tightening the last knot around a mast, with a mint cuff identifying the owner; faces, seats and blueprint stay outside the frame. If this moment must prove that the entire boat has all its parts, choose a wider completion view instead. The reviewed Duckship panel 10 combined both demands and became a broader character-and-boat illustration. This is a prompt-design diagnosis from the requested review, not proof of a particular model's general behavior.

The homage experiment offers a planning example: two kite-ferry scenes can first emphasize overwhelming storm space and later the home village awaiting a return. The vehicle stays the same; the screen's job changes. Such examples guide first-shot choices, not a requirement to make alternate renders. Do not turn experimental counts of sizes, views or adjacent-axis changes into universal quotas.

## Connect shots through information and geography

Distance can change as attention, emotion, and knowledge change. A useful sequence might move from a route to a detail to a wider result, but there is no eight-shot quota. Repeated framing is useful when the action's meaning changes, as in matching breaking and repairing hands.

Connect the reader's attention across cuts. A look toward an offscreen object can lead to the object from a compatible viewing direction; a later reaction can reveal what that sight means. Decide whether the reader knows the danger before the character or discovers it with them. Avoid making every frame an outside summary that already shows the cause, all reactions and the result.

For an emotional exchange, choose whose experience needs emphasis at the turn: the person confessing, the person listening, the distance after hurt, or the hand offering contact. Several successive front two-shots may preserve dialogue continuity but give these turns the same visual weight. Change coverage when access, attention or the relationship changes; retain a repeated frame when its changed performance or distance is the intended comparison. POV, inserts and reverse views are options, not requirements for every conversation.

Establish the people, object, route, and conversation axis. The 180-degree convention can preserve left/right relations and eyelines. If crossing it, provide a repositioning move, wider reset, or other clear spatial evidence. Do not call every deliberate axis change an error.

Maintain object state through changes in distance and angle. A damaged part stays damaged until repaired. Contact and expression can be split between an insert and a reaction, provided the relationship remains followable.

Use foreground, middle ground, background, large light/dark shapes, gaze, lines, and space selectively. Every panel need not contain three depth layers. Balloons occupy meaningful space and must not cover the important hand, face, or clue.

## Keep the shot card proportional

Start with the short sequence note above and settle the visible/offscreen boundary in the actual prompt. Add contact, continuing state, eyeline or balloon space only when the event needs them. A simple layout or plan view can resolve a difficult position during initial design; it need not be an extra generated image. Do not require alternative thumbnails or renders for every panel.

## When reviewing a requested sequence

Compare the small panels as a sequence, then inspect important details at reading size. Judge the actual spatial evidence: camera height, visible surfaces, overlap, foreground/background scale, gaze, frame boundaries and information disclosed. A prompt labeled “close-up” that produces another distant two-shot has not delivered that shot. Cropping the same picture closer can change emphasis but does not create a new viewpoint.

Separate coverage chosen in the design, conflicting or omitted prompt instructions, a result that differs from the submitted prompt, and a crop or reader assembly issue. Do not attribute all weak framing to generation failure. Preserve causal contact, object state and readable acting when proposing a different view. Source links and limits are in [earlier evidence](earlier-evidence.md); feedback and review handling are summarized in [working defaults](user-context.md).
