# English source study and reusable decisions

Inspection date: **2026-11-03**. Scope: eight complete English narrative texts (one in verse), four commercial book-preview selections, one editor's note, five publisher/teaching guides, and two indexed dictionary entries. This is not eight complete illustrated books plus four complete commercial books. No new child-reader experiment, paid purchase, or full viewing of read-aloud videos was performed.

The cards distinguish observable wording/sequence from proposed craft use. Short quotations are selective; the skill does not redistribute source texts or preview art. For commercial works, “commercial” describes the published source, not a grant to reuse it. For new drafting, the general decisions are in [English prose](english-prose.md), [audience and language](audience-and-language.md), and the visual references.

## Complete narrative texts

### E01. A House for Mouse — Michele Fry; Amy Uzzell; Jennifer Jacobs

[Official English reader](https://bookdash.github.io/bookdash-books/a-house-for-mouse/en/) · [current Book Dash entry](https://bookdash.org/books/a-house-for-mouse/). Read all narrative text and the reader's image descriptions. This was not a pixel-by-pixel analysis of every illustration.

**Observed:** invitations repeat while the discomfort changes. “Bouncy and muddy,” “noisy and wild,” and “cold and wet” turn the same night's sentence toward different discomforts; “warm and cosy” answers the accumulated need. The objects do not need new magical rules.

**Use:** retain a stable English sentence frame and alter the meaningful condition. Choose sensory wording that serves the eventual preference rather than listing atmosphere. “That night” supplies a clear repeated time hinge. The source's brevity is a useful counterweight to overly explanatory prose, not a universal word limit.

### E02. Whose Button Is This? — Paul Kennedy; James Woolley; Louise Gale

[Official English reader](https://bookdash.github.io/bookdash-books/whose-button-is-this/en/) · [Book Dash entry](https://bookdash.org/books/whose-button-is-this/). Read the complete text and image descriptions; not all illustration pixels.

**Observed:** a small robot's attempt to identify an owner exposes scale-related obstacles. An ordinary traffic signal is interpreted as an unfriendly person. The same button remains the purpose across movement, setbacks, and the eventual meeting.

**Use:** keep an object name stable while its context changes. Separate the character's judgment from the underlying fact. English requests and reactions can stay short while route and scale carry complexity. The practical action is returning a button; do not claim the story teaches the formal word “identification.”

### E03. The Magic Spell — Cambridge English Online / British Council

[Official one-page transcript](https://learnenglishkids.britishcouncil.org/sites/kids/files/attachment/short-stories-the-magic-spell-transcript.pdf). Read all text. The animation and its exact transformation images were not viewed.

**Observed:** a pretend potion, an initial claim that nothing happened, checking a mirror, concealment, a failed overnight search, and a parent's dismissive answer form a compact chain. The later reported appearance changes the earlier confidence.

**Use:** a character's spoken claim need not equal the narrator's fact. Delay the informative name until recognition is intended, and let a reassurance or excuse do something within the scene. The short transcript does not justify omitting necessary visual evidence from a new comic.

### E04. The Greedy Hippo — British Council

[Official one-page transcript](https://learnenglishkids.britishcouncil.org/sites/kids/files/attachment/short-stories-the-greedy-hippo-transcript.pdf). Read the complete rhyming narrative; did not inspect video performance.

**Observed:** a repeated appetite drives both rescue and renewed trouble. Rhyming clauses, repeated effort, and the increasing actions “nibble,” “bite,” and “swallow” provide oral rhythm and degree. The final physical result returns to the earlier food behavior.

**Use:** vary amount and consequence within repetition; match language for continuing effort to visible action. Rhyme is one mode, not the definition of good English prose. Do not inherit the retaliatory food trick or explicit lesson merely because the timing device is useful.

### E05. The Tale of Peter Rabbit — Beatrix Potter

[Project Gutenberg edition, complete text](https://www.gutenberg.org/files/14838/14838-h/14838-h.htm). Read from opening to ending, not every image in detail.

**Observed:** clothing, garden geometry, hiding places, and bodily movement create changing constraints. Losing shoes permits a faster gait; jacket buttons create a new obstruction; a seemingly useful hiding place has another disadvantage. Manner-plus-path phrases such as “wriggled out” make the escape specific.

**Use:** connect a precise English verb and direction to the material situation; a local solution can expose the next condition. Retain established geography and aftermath. The historical diction, long clauses, threats, and moral framing are not defaults for a present-day eight-year-old EFL reader.

### E06. Crunch and the Figs — Anu Madhavan; Yesim Serce

[Storyberries text reader](https://www.storyberries.com/bedtime-stories-crunch-and-the-figs-short-stories-for-kids/). Read the complete “as text” story through its ending; not every illustrated page or audio track.

**Observed:** the same fruit means earned work to the gardener and desired food to the squirrel. Descriptions of care make the possessive complaint “my figs” meaningful; later sharing changes the access, not the fruit. Looking around the garden supplies a new perspective before a concrete arrangement. Specific movement and a bodily response mark being caught.

**Use:** sensory and evaluative detail can prepare conflicting interpretations; let observation precede a changed decision. Select the short work's necessary pieces rather than importing the source's lengthy garden introduction and explanatory ending. The site's stated age/read time is publisher labeling, not a verified level for this learner.

### E07. The Halloween Parade Problem — Maggie Murphy; Jennifer Zivoin

[Official LADYBUG story PDF](https://aws.cricketmedia.com/media/20161013200902/Ladybug-halloweek-parade.pdf), five pages, printed pp. 25–29. Read the entire extracted main story. No claim of full-issue reading or detailed image analysis.

**Observed:** the desired costume creates the walking problem. “The robot’s shiny face smiled. Mouse’s furry face frowned.” The parallel wording makes appearance and experience conflict. A slow gait becomes a short toy performance after a friend reframes the parade role. A feet-related exchange links the practical suggestion to the character's refusal.

**Use:** repeat syntax while changing the subject and response; let a costume or prop express a feeling different from its wearer. Redesign the use of an established limitation instead of granting a new ability. Wordplay needs linguistic support and need not survive unchanged in a beginner adaptation.

### E08. The Witch Who Couldn't Order In — Andrea L. Mack; Lars Leetaru

[Official SPIDER story PDF](https://aws.cricketmedia.com/media/20161013200850/Spider-Witch.pdf), six pages, printed pp. 24–29. Read the main narrative completely. Extraction also includes an independent running mascot conversation; those lines were not treated as the witch's plot.

**Observed:** losing a familiar magical tool makes shopping difficult. The witch interprets ordinary produce and tins through her existing knowledge, while other shoppers react to her differently. A cat's tail changes punctuation-like shape with its attitude. The missing repair supply returns through the cat's separate action.

**Use:** a single worldview can shape sensory descriptions, questions, mistaken confidence, and consequences. Track the helper's behavior rather than adding an unprepared final rescue. Distinct diction can belong to one character. The article's idiom and side conversation should not be imposed on all learner prose.

## Commercial book samples: inspect the available pages, not an imagined full book

### E09. A Friend for Dragon — Dav Pilkey, Scholastic Acorn

[Official excerpt PDF](https://www.scholastic.com/content/dam/scholastic/site/pilkey/excerpts/dragon/Dav-Pilkey-Friend-For-Dragon-Read.pdf). Twelve PDF pages include cover/matter and the opening story text, printed pp. 2–6. Read the opening. The copyright-page synopsis gives later events but is not a close reading of the ending.

**Observed:** a plainly stated loneliness causes a search. The question “Will you be my friend?” stays stable across encounters while the reason for refusal changes. Location, meeting, request, answer form a trackable unit.

**Use:** keep an English syntactic frame recognizable while shifting the social obstacle. Simple dialogue can carry rejection and longing without a paragraph explaining each feeling. Do not infer exact whole-book pacing, an apple scene's wording, or reader response from the opening excerpt.

### E10. Little Mouse Gets Ready — Jeff Smith, TOON Books

[Official sample gallery](https://www.toon-books.com/little-mouse-gets-ready.html). Viewed the six gallery images: front/back covers plus four interior spreads, printed pp. 10–11, 18–19, 20–21, and 28–29. Not the whole book.

**Observed:** task talk directs attention to a tag, a tail opening, shoes, sleeve, and buttons. Tight hand views make effort legible; repetitive completion words register progress; a wider silent spread changes scale and density. The button passage visibly supports the directional meaning of “through.”

**Use:** align an English action/particle with actual contact and passage, then vary framing when information changes. A silent wide image can follow concentrated action without another explanatory balloon. The covers and separated sample pages do not establish every intervening causal beat or the full ending.

### E11. Benny and Penny in the Big No-No! — Geoffrey Hayes, TOON Books

[Official sample gallery](https://www.toon-books.com/benny-and-penny-in-the-big-no-no.html). Viewed six gallery images: covers and printed pp. 8–9, 12–13, 22–23, 26–27. These are selected spreads, not a continuous complete story.

**Observed:** a missing pail prompts an accusation, denial, and fear of a neighbor. Speech and bodily pressure differ: “I was just ASKING!” follows aggressive delivery. The samples later show corrective evidence, a differently owned pail, admission, and another physical mishap. Balloon size, body, and spacing distinguish reactions.

**Use:** keep guesses qualified, give a concrete referent to “it” and possession words, and let a defensive line conflict with the behavior already seen. An apology can coexist with an imperfect character and further comedy. Do not reconstruct the unsampled scenes as observed facts.

### E12. Eva's Treetop Festival — Rebecca Elliott, Scholastic Branches

[Official entry](https://www.scholastic.ca/our-books/book/evas-treetop-festival-a-branches-book-owl-diaries-1-9780545683623) · [publisher's preview image](https://assets.scholastic.ca/public/excerpts/9780545683623.jpg). Viewed only printed pp. 6–7, plus the product description. No whole-story close reading.

**Observed:** first-person enthusiasm, contractions, paired waking/sleeping states, and illustrated abilities introduce a voice through a diary-like page. Some short text sits with matching pictures rather than in continuous paragraphs.

**Use:** character voice can coexist with repeated simple grammar and a non-caption page design. This spread supports a discussion of voice and layout; the synopsis alone cannot support claims about the festival climax or chapter-by-chapter humor.

## Editorial and teaching context

- **E13. I Want My Hat Back — editor's note, Liz Bicknell.** [Official one-page PDF](https://d3kr0g7umcubly.cloudfront.net/candlewick-press-us/pdfs/creator-note/9780763655983-notes-1.pdf). Read the note and [publisher description](https://www.candlewick.com/9780763655983/i-want-my-hat-back/), not the book text. Despite the resource's “Creator Note” label, the signed voice is the editor's. The note connects restrained illustration, all-dialogue text, and repetition; it is an editorial observation, not a complete evidence card for the book's wording or final reveal.
- **G1. TOON Level 1 guidance.** [Publisher criteria](https://www.toon-books.com/level-1-grades-k-1.html). Read the stated sight-word, sentence, theme, and panel characteristics. These describe this publishing line; do not turn its one/two-panel pages or native-English reading grade into universal limits or an EFL placement.
- **G2. Gail Ellis, illustrated storybooks.** [British Council article](https://www.britishcouncil.org/voices-magazine/how-teach-children-english-using-illustrated-storybooks). Read the article, not the linked webinar. Select for both linguistic and cognitive suitability; support with images, voice, and prediction. This informs separate reading modes rather than a claim that all authentic books suit every learner.
- **G3. Carol Read, The Magic of Storytime.** [TeachingEnglish article](https://www.teachingenglish.org.uk/professional-development/teachers/managing-resources/articles/magic-storytime). Read the article. Pauses, repetition, gesture, illustration, revisiting, and later transfer are teaching options. The generated story's learning effect remains untested.
- **G4. Oxford Owl phonics guide.** [Oxford University Press](https://home.oxfordowl.co.uk/reading/phonics/). Read the explanations of decoding and sequences; did not inspect every linked video. A specified taught spelling sequence is distinct from short, familiar, image-supported prose.
- **G5. SPIDER editorial guidelines.** [Publisher page](https://cricketmedia.com/spider-submission-guidelines/). Read the fiction and audience criteria, not as an instruction to submit. It asks for engaging, believable characters/worlds and gives a market-specific fiction length. Those constraints describe that market, not the user's one-page comic. Submission availability, payment, and rights must be checked anew if an actual submission task arises.

## Word-sense checks

Cambridge's indexed excerpts for [come up with](https://dictionary.cambridge.org/dictionary/english/come-up-with) and [identification](https://dictionary.cambridge.org/dictionary/english/identification) were visible on 2026-11-03; direct dictionary pages failed. Used only to verify the plan/idea sense and identity-evidence sense in [vocabulary scenes](vocabulary-scenes.md). No claim of reading the full dictionary usage notes.

## Where to look next

| Pool | Useful material | Limitation to keep visible |
|---|---|---|
| Book Dash | Complete short English picture-book texts and source packages | A translated edition is not automatically originally composed in English; open reuse has attribution conditions |
| British Council LearnEnglish Kids | Complete story transcripts with learner-oriented support | A transcript is not observation of the video's action or vocal timing |
| Cricket Media | Authorized magazine story PDFs and editorial expectations | A story can coexist with independent side comics; an issue or market has its own audience |
| Scholastic Acorn / Branches | Early-reader and newly independent-reader excerpts | Excerpts and marketing descriptions are different evidence; levels are line-specific |
| TOON Books | Actual sample spreads, dialogue and visual-reading support | Nonconsecutive samples cannot prove the entire arc |
| Storyberries | Complete original story text across several modes | Length, diction, explanatory passages, and stated ages vary; select rather than copy the house style |
| Project Gutenberg | Complete historical English texts | Historical syntax, cultural assumptions, and emotional intensity need current editorial judgment |

Do not keep searching only for sources that confirm an existing technique. Include a contrasting case: a quiet ending, a talk-led piece, a physical scene, or a repetitive learner text. Add a guideline only when it changes a useful drafting decision; otherwise retain the example as evidence of range.
