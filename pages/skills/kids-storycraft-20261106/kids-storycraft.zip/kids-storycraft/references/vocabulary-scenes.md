# Vocabulary that matters to a small event

Choose a target word or phrase, part of speech, one sense, and a natural phrase frame. A small event should require that meaning, not just display the word in a title. Keep the surrounding English familiar when the target carries the new load.

Choose a compatible conflict or discovery before selecting a generic opener. In the live-word homage experiment, `fathom` suited learning a strange size rule, `bias` suited unequal admission before ability was considered, and `contempt` suited a relationship reversed by unexpected help. These are authored examples, not fixed word-to-plot assignments. A prepared opener can be reused when its situation supports the supplied sense; do not force every word into the same small-object mystery.

## Give the meaning a job

| Job | Possible target | Necessary evidence |
|---|---|---|
| Obstacle | stuck, heavy | What cannot move, fit, or be lifted, and why |
| Means | pull, stretch, lift | Contact, force direction, tool, before/after difference |
| Clue | empty, missing, different | An observable state and any needed comparison |
| Reaction or relation | proud, surprised, behind | The cause plus body response, or both spatial referents |

Select the main job. Do not give every word a rescue, mystery, and competition at once. An opaque closed box does not prove “empty”; a thought bubble with a light bulb alone does not establish the particular plan someone came up with.

For a list of required words, place each sense in the ongoing conflict, attempt, clue or response where it naturally belongs. If a word needs its own beat, connect that beat to a consequence or a meaningful change in the reader's expectation. Ducks can cram hats until a wet box splits, making a sturdy replacement useful in the next scene. When shortening the prose, preserve the concrete action, choice, voice or payoff inside the requested length. Keep the supplied meanings and required coverage.

## Two useful cases from this user's requests

**Come up with:** use the idea/plan sense. First make the problem and an available resource understandable. Then show the character noticing a usable relation and proposing or applying a specific plan. `“Can you come up with a plan?”` and `“I've come up with one. Use the tray.”` can be natural if the picture makes the tray's relevant function clear. Do not show someone physically coming up a staircase as the only evidence of this idiomatic sense.

**Identification:** choose either establishing identity or evidence of identity; do not mix those with merely finding a lost object. For the document sense, a club doorkeeper can ask `“Identification, please.”` while comparing a card with its holder. A mismatch needs legible matching features or a clear photograph, not text too small to read. The formal line fits a doorkeeper role and can be funny in a child's game; it need not become every child's everyday register. Keep an optional meaning gloss outside the action.

The sense checks above agree with Cambridge's entries for [come up with](https://dictionary.cambridge.org/dictionary/english/come-up-with) and [identification](https://dictionary.cambridge.org/dictionary/english/identification), inspected through indexed dictionary excerpts on 2026-11-03; direct pages returned access errors. These miniature situations are new editorial examples, not examples quoted from the dictionary.

## One or two scenes

Set a desire, an obstacle, and an expectation; then choose a result, reversal, or discovery. The first image may already show the word's meaning, or the second may establish it through action. Full resolution is optional: the problem may spread to another character or a clue may merely change the investigation.

Dialogue should ask, request, reassure, boast, confirm, or evade for a reason. Do not stop the story so a character can recite a dictionary. A mostly silent narrative engine can use a brief educational caption or added line; identify it as an adaptation rather than an authentic feature of the source show.

For each frame, select one frozen instant and readable actors, contacts, gaze, and state. Keep character design and props consistent. New art uses an image-generation tool; a request only for a scene concept does not require generating it.

## Meaning questions for design or a requested review

Use these questions when choosing the initial situation. Apply them to finished wording or art only when the user requests review; do not introduce a separate scoring or regeneration stage into one-take creation.

- Hide the wording briefly: can the image support the intended action or relation? Some abstract meanings still need the spoken proposition; do not claim a face alone proves them.
- Replace the target with an unrelated meaning: would the whole event work unchanged? If so, strengthen the connection.
- Restore the dialogue: would this character have a reason to say it now, and does the grammar express the selected sense?
- For a repetition, what changes in actor, amount, outcome, or attitude?
- Does the child have evidence for a prediction or inference? A question without useful information is not participation.

Keep idiomatic sense stable while the situation becomes funny. Do not explain the same physical evidence as incompatible target meanings merely to include more words.
