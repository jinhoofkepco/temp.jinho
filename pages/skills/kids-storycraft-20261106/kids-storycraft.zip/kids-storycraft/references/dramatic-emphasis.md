# Make the important moment land

Use before generation to give the first work's preparation, important change and aftermath different jobs. Also use when a review of flat dramatic emphasis is requested. The earlier cake-cart story received the user's explicit judgment that it was clearly more entertaining than before; this does not isolate which technique caused the improvement. Sources and the observation scope are in [earlier evidence](earlier-evidence.md).

## Name the point beyond the event label

“The cart rolls” names an event. “The reader sees the drop before the runners do and waits to find out whether the improvised catcher will hold” specifies a dramatic point.

At important transitions, consider:

`current goal / reader's previous belief / immediate focus / information disclosed or delayed / changed expectation after this beat`

Not every beat needs a peak. Orientation, preparation, time to listen, and a quiet reaction can make the key change possible. A small discovery can be the peak; danger, destruction, and louder lettering need not increase.

## Prepare → change → receive the result

Select the preparation, decisive change, and reaction the event needs. A prepared catching pose raises a question without answering whether the catcher will succeed. A smiling success pose in the preparation panel closes that question early.

Distinguish suspense from surprise and reinterpretation. For suspense, let the reader see a risk or route while a result remains unresolved. For a surprise, preserve enough prior facts to make the reveal intelligible. For reinterpretation, earlier facts stay true while their meaning changes.

The prose and layout must cooperate. Do not describe the successful rescue before displaying preparation and impact. A companion line can split two consequences: an object stops while its contents continue. The pictures must show the same distinction.

## Change the condition, not merely the viewpoint

Repeated running becomes a sequence when the route, obstacle, distance, available tool, or choice changes. Different angles on unchanged running do not create new narrative information.

Establish an obstacle or tool before the turning point depends on it. Show the relevant scale and contact. A hand close-up, a wide route, a large approaching foreground object, and a still reaction serve different functions; use the ones this event needs.

## Use contrast around the peak

Choose a functional contrast: relaxed space → tiny break; broad route → tight face; held breath → release; moving crowd → one motionless listener. Do not maximize every axis at once. A large panel can carry impact, aftermath, or discovery; a small insert may hold the most important cause.

Panel size does not automatically specify reading duration. A larger frame with a tiny, obscured contact may still fail. A quiet repeated composition can make a changed expression especially visible. [Cinematography](cinematography.md) supports this design but cannot replace the causal chain.

## Adapt film time to a still reading sequence

A camera move discloses information over time. A static image does not inherit that move. Pick the decisive instant, split the reveal across frames, or design an intentional path of attention within a single frame. Do not convert seconds mechanically into panel counts.

A paper page turn, continuous scroll, and one-panel reader expose neighboring information differently. Choose the planned layout so a withheld ending is not exposed before its setup. A sequential-view option can help a particular reveal, but it cannot repair a missing cause or weak performance.

## When reviewing a requested finished sequence

Point to the actual evidence of the peak. Remove a preparation frame mentally: does the reader wait for a different result? Compare similar panels: do they add different information? Look for a sentence, thumbnail, or adjacent reveal that answers the question early.

After the decisive change, provide the result or its personal meaning where needed. Then stop at the earned ending rather than adding another moral. Technical validity, the writer's staging judgment, and audience excitement are separate findings.
