# Working defaults

Write child-facing stories in English by default and discuss the work in the user's language. Adjust age, English level, format, panel count and reading mode to the request.

Plan the first complete take and retain the submitted prompts and first outputs. Keep feedback and production records in the private workspace. For a requested review, identify the work and version, distinguish the user's observations from editorial judgments, and preserve evidence for later revisions.

Use the destination and repository instructions supplied for the project. Check the latest changes and preserve existing links when publishing. Publication requires a request for that destination.
