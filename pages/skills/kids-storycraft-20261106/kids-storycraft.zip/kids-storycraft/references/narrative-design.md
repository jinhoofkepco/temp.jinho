# Narrative design across prose, comics, and episodes

Keep one causal spine and one reader experience. A child wants something, an obstacle changes the available choices, and the child or protagonist does something that changes the outcome. A small goal can matter intensely: finishing a game, keeping a place, looking competent, keeping a promise, or finding a companion.

For the first complete work, choose both a reason to care and an interesting situation: a strange rule, conflicting wants, an approaching mishap, a reversal of who needs help, or another specific attraction. A modest goal still needs a reason to follow its next change. Plan the important consequence and outcome before expanding prose or assigning picture prompts. Repeated looking, walking or handling becomes a sequence only when it changes what can happen next.

## Develop the premise through consequences

Begin with one understandable imaginative departure or one ordinary situation under pressure. A talking object still needs its own desire; a magical device needs a readable rule. Let the attractive property also create difficulty. Do not expand the story by introducing an unrelated special object whenever the current attempt fails.

Follow `attempt → consequence → changed condition → next choice`. The condition might be physical, informational, social, temporal, or emotional. Greater size is only one form of escalation. Discovering a different problem, switching the helper and helped, or making a different use of the same place can move the story.

Use the outline to decide why the next scene happens now. A discovered clue can redirect the search. A successful move can open a route and expose a new risk. A recovered object may have become important to someone else. When adjacent beats repeat the same information or outcome, read the plan without one of them. Merge beats if the next action, expectation and emotional rhythm still work. Give a pause or repetition a specific job, such as holding a doubt or making a changed result comparable.

A helper can contribute without taking the protagonist's agency. Connect the decisive help to a request, observation, decision, or earlier action. Do not resolve the climax with a new ability or a tool that appears only at the moment of rescue.

## Design the reader's experience alongside the events

Keep fact, interpretation, and reader knowledge separate. A character can call a shadow frightening while another sees shelter; the same physical facts need not change. Choose a detail because this character notices it now and because its property may matter later. Not every attractive adjective needs a later payoff.

Decide whether the reader knows more, the same, or less than the protagonist. Knowing the source of the trouble can create anticipation; discovering the source together can create surprise. Withholding every causal fact creates confusion rather than a fair mystery.

Use a repeated phrase or action to reveal a changing situation. The same request can first be confident, then inconvenient, then affectionate; another speaker can inherit it. Repeating three times is not itself an arc. Likewise, replacing every repeated noun with a synonym can make a small story harder to follow.

## Connect humor to what the character wants

Distinguish a joke's job: introducing a trait, causing the difficulty, obstructing the plan, revealing failure, releasing tension, or returning a setup at the end. A character's earnest tactic can create the joke; a separate gag need not interrupt the event.

Use the mismatch between a claim and an action, a tiny goal and an elaborate procedure, or two people interpreting the same evidence differently. A repeated success can tempt a character to take the tactic too far. Silence and a delayed reaction can complete a joke. Repeated humiliation is not a substitute for motive or a developing situation.

For young English learners, a joke that requires an unfamiliar idiom plus a second meaning has extra language load. Keep the physical or social situation understandable before adding wordplay. If language is the joke's actual subject, provide a clear setup rather than treating a failed translation as absurdity.

## Earn the ending

Revisit an earlier object, gesture, phrase, or relationship when its use or meaning has changed. A callback is not merely repeating a noun. A new final object, random line, moral, hug, or gift does not repair an unprepared resolution.

Choose the emotional landing separately for each story: restored purpose despite an imperfect result, a small invitation with hurt still present, a discovered explanation, a shared inconvenience, or another round of a joke. Do not force every story into misunderstanding → apology → forgiveness.

When adapting a source, identify the working relation among desire, obstacle, reversal and payoff before changing names or objects. For an original story inspired by a source, change selected desires, materials, actions or outcomes while keeping the new causal sequence coherent. For a requested retelling or homage, preserve the mechanism that makes the chosen situation work; do not replace every element merely to demonstrate novelty. Keep the requested mode and source-use conditions clear. Korean folklore can supply a concealing ability with a visible flaw, previously introduced small helpers with different functions, or a troublesome property used differently. Keep a traditional mechanism distinct from a particular modern retelling's phrasing and scene order. Provenance is in [earlier evidence](earlier-evidence.md).

## When revision is requested: work from whole to part

First test the event chain and information order. Then identify a sentence's main job: action, observation, interpretation, decision, orientation, pause, or connection. For an important detail, compare deletion, neutral wording, and a changed position. What changes in the reader's expectation, orientation, or feeling? Preserve functional detail; reduce repeated explanation. This is an authorized revision method, not an automatic post-generation pass in one-take production.

An outline is a working tool, not a mandatory deliverable. Produce the finished prose or scene if requested. Use [story modes](story-modes.md) for a group of contrasting pieces and [English prose](english-prose.md) for the sentence-level pass.
