# Audience, English load, and reading mode

Ask or infer three separate things: developmental age, English understanding/reading ability, and how the material will be used. An eight-year-old EFL learner is not automatically equivalent to a native-English Grade 2 reader. A published book's interest age, school grade, Lexile, and another publisher's numbered level measure different things.

If missing information does not prevent useful work, state a brief assumption and proceed. For a provisional audience around age eight, use familiar surrounding language and preserve worthwhile choices and feelings. Do not demand a formal placement test before writing.

| Use | Tune the language and delivery | Preserve |
|---|---|---|
| Adult reads aloud; child follows pictures | Natural phrasing, a purposeful refrain, pauses and some image-supported unfamiliar words | Voice, atmosphere, anticipation, participation |
| Child reads independently | Clear actors, stable object names, manageable clause load and explicit necessary connections | Agency, a fair clue, humor, emotional meaning |
| A few vocabulary scenes | Familiar surrounding words and one target sense in a natural phrase | An action or discovery that needs the meaning |
| Newly independent chapter reader | Connected paragraphs, increasing information and character voice with visual support where requested | Motive and consequences beyond a string of captions |
| Specifically decodable text | The actual taught sound/spelling sequence and permitted exception words | A coherent event within the requested constraints |

Do not call easy-looking prose decodable without the relevant phonics scope. [Oxford Owl's phonics guide](https://home.oxfordowl.co.uk/reading/phonics/) distinguishes decoding through sound–spelling knowledge and notes that schemes teach sequences differently. This is a different constraint from short sentences or image-assisted vocabulary.

[Gail Ellis's British Council article](https://www.britishcouncil.org/voices-magazine/how-teach-children-english-using-illustrated-storybooks) explicitly separates linguistic and cognitive suitability. Its teaching guidance supports choosing material and scaffolding; it does not certify a generated story's grade or educational effect.

## Reduce avoidable load before reducing the story

Look for unclear pronouns, several new content words in one clause, nested time relations, an unfamiliar idiom carrying the only joke, or a vital fact hidden behind a difficult sentence. Rephrase those first. Keep the child's meaningful motive, hesitation, discovery, and decision.

Target words can be longer than surrounding words if the event makes them inferable. Offer a concise optional gloss or follow-up outside the story when useful. Repetition should support a new context or outcome, not turn every sentence into a drill. Do not interrupt every dramatic beat with a comprehension question.

For a middle-school-level request, adjust clause relationships, vocabulary density, and inference to the specific reader. Use ordinary because/when/while or modals when they do useful work. A longer sentence is not itself more mature. Seriousness can arise from responsibility and the cost of a choice without death, cruelty, or a speech about the lesson.

## Participation needs actual evidence

A prediction prompt needs visible or stated grounds: what tool might fit, which footprint differs, whether a stack can hold. Pause before the answer when the format permits it. A repeated line can invite participation, but a fixed quota of refrains or questions is unnecessary.

Carol Read's [storytime guidance](https://www.teachingenglish.org.uk/professional-development/teachers/managing-resources/articles/magic-storytime) discusses gesture, pauses, repetition, illustration, and later language transfer. Those support options motivate the choices here; the precise load adjustments above are editorial proposals, not results of a new reader study.
