# Emotional acting in words and images

Use to plan the first work's emotional changes, and when the user requests a review of weak or abrupt acting. More tears, sweat, or a larger open mouth cannot by themselves establish why a moment matters. Disney production examples informed the earlier work; observation limits and links are in [earlier evidence](earlier-evidence.md).

## Meaning → first reaction → next choice

Establish what the character expects, values, or fears losing. Then distinguish the stimulus, involuntary response, and deliberate action. Being startled by a sound, fearing discovery, recognizing betrayal, and deciding to forgive can all require different attention and behavior.

Select the useful bodily evidence: line of the torso, weight, shoulders, head tilt, gaze, hands, distance, and the other person's response. Facial acting belongs in this pattern. A tense smile can mean concealment only when something worth hiding has been established.

| Moment | Possible event-specific evidence | What must be established |
|---|---|---|
| Surprise | A hand pauses mid-task; eyes snap toward the changed object | What changed and what the character expected |
| Embarrassment | An unfinished explanation, a guarded object, a glance at the witness | What might be exposed |
| False reassurance | Easy words or a large smile while the hand blocks a pocket | The hidden fact and why the other person matters |
| Shock after discovery | The body stops or recoils; attention fixes on the evidence | What the evidence means to this relationship |
| An apology | The concealed hand opens; the character acknowledges an action and waits | The action that caused harm |
| Acceptance or a boundary | A listener considers, then offers a particular next action | The harmed character's own choice |
| Renewed cooperation | Roles or handling of the disputed object actually change | What was in conflict before |

These are candidates, not a pose dictionary. Slumped shoulders do not always mean sadness; silence can carry strong feeling. Constant exaggeration makes neighboring emotions harder to distinguish. Choose one or two contrast axes with a job: open/closed posture, looking/avoiding, holding/releasing, near/far, movement/stillness.

## Give relational changes enough time

Do not compress harm, realization, apology, acceptance, and celebration into one reaction. If the arc depends on listening or hesitation, allow it a separate beat. An explanation of motive does not automatically excuse the harm.

Forgiveness is one possible action by the harmed character, not an obligation caused by someone else's apology. A guarded invitation or a practical next step may be enough. Shared smiling or a hug is not the only visible form of harmony.

Connect reconciliation to the disputed behavior: the person who hid the tool asks to borrow it; the proud performer accepts help; the person who interrupted makes room to listen. An unrelated new gift does less to prove that this conflict changed.

## Let prose add the missing inner relation

The prose can add the feared consequence, an almost-spoken answer, a remembered promise, or the time needed to choose. It need not list every muscle the image already shows. Keep an emotion word if it quickly orients the reader; do not ban “afraid” and then prove fear six different ways.

An original example: `“I didn't touch it.” Nora pressed her palm over the dent.` This needs an established object and reason to conceal it. Later, moving the same hand aside can carry the decision to admit what happened. The prose should not introduce an unseen past event solely to explain an otherwise generic pose.

## When reviewing requested work: inspect neighboring moments

Compare the important before-and-after panels. Can the reader identify what changed in gaze, weight, hand, or distance? Is a mismatch between speech and body intentional concealment or a rendering error? Is the character celebrating before hearing the apology or seeing the outcome?

Preserve anatomy and identity in a readable held pose; a film's passing distortion may look wrong in a still panel. Use both small-thumbnail body checks and larger eye/hand checks. If emotions are legible but the moment still lacks force, move to [dramatic emphasis](dramatic-emphasis.md) rather than enlarging expressions automatically.
