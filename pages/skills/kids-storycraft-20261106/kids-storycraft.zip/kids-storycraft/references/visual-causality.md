# Visual causality: turn the intended meaning into evidence

Use for first-draft comic panels and storyboards, and for repairs when requested. The inflatable-chair feedback establishes a useful action-evidence case. Select evidence appropriate to the current event; it does not require every comic to become a mechanical puzzle. Source scope is retained in [earlier evidence](earlier-evidence.md). Separate output inspection from one-take production.

## Start with the meaning, then the drawable evidence

“The bear deliberately lets the air out to stop the game” needs more than an air-puff effect. Possible evidence: the hand opens the valve, the cap is visibly displaced, air leaves that point, the fabric has no tear, the bear looks satisfied, and the disappointed squirrels register the result. Select the necessary elements and make the decisive contact readable.

Choose one instant: opening, holding open, or reacting to the deflated object. A panel cannot automatically convey an entire sequence of separate actions. If the meaning needs a transition, use neighboring panels or choose a simpler event.

The picture's center is the relevant evidence, not necessarily the face or a decorative background. A wide frame can establish geometry; a detail can show a mechanism. Keep the actor identifiable through the previous setup, sleeve, body, or direction of force without forcing a full cast into every insert.

## Time, degree, and knowledge are relationships

- **At last:** show or establish the earlier nuisance or wait. A relaxed smile alone proves relief only weakly and does not prove duration.
- **A little:** compare with earlier size, pressure, or amount. Slight swelling and remaining folds differ from full inflation; dialogue cannot make a fully inflated chair a small change.
- **Hard:** show contact with a non-yielding surface and, where useful, contrast it with the earlier cushion. Do not add a nail or thorn and accidentally invent a different cause of discomfort.
- **While his back is turned:** establish where the head and eyes point, what occupies attention, and what the other actor hides. A turned torso with eyes looking directly at the secret action undermines the intended knowledge gap.
- **Keeps pressing:** preserve continuing contact, hose connection, and force. Squirrels standing beside the pump do not prove continuing pumping.
- **Almost / tries:** show the threshold not crossed or the resistance not overcome. Do not depict a completed catch under a line saying it nearly happened.

English aspect and particles are part of this check; see [English prose](english-prose.md).

## Track states independently of camera angle

For a causal prop, track count, owner, position, connections, condition, and movement. Example: chair = normal → bouncy → deliberately deflated → flat → slightly inflated → oversized → torn. The tear does not appear during the earlier deliberate deflation.

Plan the valve's location and number, hose ends, pump height, and foot contact. Carry an object's former position into the next scene's description: when it moves or breaks, do not also request an intact duplicate in the background. Do not reset a damaged object between angles before the repair occurs.

In a repeated group action, one character can depress the pedal while another is about to land and a third is crouched. That can show one instant of a continuing rhythm. Repeating the same character's separate time steps inside an unmarked frame is a different device and may confuse the event.

## Choose readable evidence before generation

A useful panel note is:

`intended meaning / frozen instant / necessary contact, state, and gaze / attention order / continuing state / likely misreading`

Use only useful fields. Prefer a clear positive description over a long list of forbidden errors. If an intended instant depends on several hidden contacts, forces or separate actions, simplify it while writing or distribute it across scenes. Complexity is not just the number of characters. Three clearly coordinated participants can be easier to draw meaningfully than one actor operating several obscured connections. A short layout note may be sufficient; do not add a compulsory generated-thumbnail pass.

## When review or repair is requested

Inspect the actual result at panel size and in sequence. Briefly hide dialogue to test the basic cause and effect, then restore it for voice, words, and jokes that intentionally depend on both channels. A silent-comprehension test is diagnostic; not every comic must be fully intelligible without text.

When revising, preserve successful parts and repair the failed meaning with the necessary neighboring setup or reaction. Do not regenerate good panels merely for superficial consistency. The writer's knowledge of the script is not independent reader evidence.
