# Earlier evidence retained from the two merged skills

These are records of work performed on **2026-11-02**, carried forward into the English skill on 2026-11-03. The links were not all reopened in the English-source pass. Their recorded scope is preserved; none becomes a new claim of full viewing or a measured effect on children. The original skill folders are backed up outside active discovery.

## Korean fiction: what transfers to English

Earlier reading covered six newspaper stories, six Donga contest texts, two stories in a KB collection, three complete comic jokes/episodes, and two one-page reader creations. One reader creation introduces an imaginative setting rather than a complete conflict/resolution arc; do not relabel the set as nineteen complete plotted stories. Books and magazine issues were not read in full.

The transferable unit is a relation between viewpoint, detail, action, information, and outcome. Korean sentence order, honorific relations, and ideophones require reworking into natural English; they are not automatically copied.

| Work / direct source | Earlier observation and transfer |
|---|---|
| [아기 뱀, 또롱이](https://www.kidshankook.kr/news/articleView.html?idxno=18453), author unconfirmed | The same body receives loving and rejecting evaluations. The user specifically valued how the affectionate sensory introduction prepares the later hurt. Keep the judging viewpoint and whole-story contrast, not a mandatory love-to-hurt plot. |
| [냄새 맡은 값](https://www.kidshankook.kr/news/articleView.html?idxno=170), Park Sang-jae / Seo Young-gyeong | A short confirming exchange commits an opponent to a premise later answered through another sense. Dialogue is an action, not merely delivery of a punchline. |
| [다시 째깍째깍](https://www.kidshankook.kr/news/articleView.html?idxno=18502), Do Geon-yeong | Clock/heart language parallels care, but a battery remains the mechanical cause. Separate metaphor from the story world's physical rule. |
| [오픈런](https://www.kidshankook.kr/news/articleView.html?idxno=18212), author unconfirmed | Texture changes with the child's attention and desire. Sensory description can prepare an emotional turn without changing physical facts. |
| [조폭 아저씨의 비밀](https://www.kidshankook.kr/news/articleView.html?idxno=18144), author unconfirmed | A label carries the child's interpretation; new information reframes already observed actions. Do not inherit stigmatizing appearance/job associations. |
| [플라스의 목소리](https://www.kidshankook.kr/news/articleView.html?idxno=17958), Lee Geum-an | One material moves between figurative, imaginative, and concrete uses. Keep that linkage separate from a long environmental explanation. |
| [사과에 구멍이 있어요!](https://sinchoon.donga.com/View?cid=4452700), Gong Mun-jeong, 2014 | Hand verbs develop from stopping to observing and making. Sound words carry differing action durations; find an English rhythm/action equivalent rather than transliteration. |
| [우주놀이](https://sinchoon.donga.com/View?cid=4452754), Lee Su-an, 2013 | Household holes and light acquire a new use through play. The object remains stable while experience changes. Do not use disability as a device for someone else's growth. |
| [가벼운 인사](https://sinchoon.donga.com/View?cid=4450843), Sim Sun, 2020 | Contact, weight, and distance carry relationship; a hand's changed use connects the arc. Loss and death are source material, not defaults for a brief playful piece. |
| [놀이터는 망하지 않는다](https://sinchoon.donga.com/View?cid=4653310), Lee Jeong-min, 2024 | Borrowed adult labels meet a child's changing interpretation. Movement pace can express competing desires. |
| [눈이 마주친 순간](https://sinchoon.donga.com/View?cid=5377540), Na Hye-jin, 2025 | Similar replies and averted gazes can have different reasons. Preserve who knows what without importing a long alternating interior narrative. |
| [날 좋아해줘](https://sinchoon.donga.com/View?cid=6035935), Choi Seung-yeon, 2026 | Previously supplied facts support a changed emotional interpretation. Repeated titles/roles shift from pride to burden. |
| 안녕히 계세요, Min Ji-in | In the [KB official collection](https://omoney.kbstar.com/quics?page=C017659), *동화는 내 친구 33* (2024), printed pp. 11–23 / PDF pp. 12–24. The pencil case's material matters to the child's prior mistake; dropping liquids and repeated naming link actions and feeling. |
| 노란 운동화를 찾습니다, Kim Hyeon-ju | Same collection, printed pp. 53–66 / PDF pp. 54–67. A color changes from an identifying detail to evidence of knowledge when another speaker names it first. |
| [엄마의 흰머리](https://www.boribook.com/uploads/picture/1905_original_%EB%AF%B8%EB%A6%AC%EB%B3%B4%EA%B8%B01.png), Shin Yeong-hui | Actual preview pp. 22–23 of [만득이는 아무도 못 말려](https://www.boribook.com/books/499). A child's application of an adult's explanation changes the expected lesson. |
| [바보는 누구?](https://www.boribook.com/uploads/picture/1906_original_%EB%AF%B8%EB%A6%AC%EB%B3%B4%EA%B8%B02.png), same book | Actual preview pp. 56–57. An already visible posture becomes meaningful after a reply. Retain the timely evidence, not the insulting tone. |
| [구명보트](https://gaeddong.boribook.com/images/gaeddong_sample182ho/TIFF_38.jpg), author unconfirmed | Actual printed p. 102 in the official sample. One mistaken linguistic premise expands through the mother's participation. A Korean homophonic joke needs redesign in English. |
| [태양 빙수 가게](https://gaeddong.boribook.com/images/gaeddong_sample182ho/TIFF_52.jpg), Lee Yeon-seo | Printed p. 134, complete one-page reader creation. Imaginative introduction and continuation promise, not a complete plotted resolution. |
| [뿅뿅이](https://gaeddong.boribook.com/images/gaeddong_sample182ho/TIFF_53.jpg), No A-hyeon | Printed p. 135, complete one-page reader creation. An omitted interval lets the changed face supply the reveal. |

Newspaper and KB texts were read through their endings. Donga's complete works, not just judges' comments, supported the word/action notes. Comic images were actually inspected. The comics were concentrated in Bori/개똥이네 material; award recognition and the creators' ages do not establish the target child's preferences.

### Earlier source pools

For renewed Korean-source work: [소년한국일보 동시·동화](https://www.kidshankook.kr/news/articleList.html?sc_sub_section_code=S2N89&view_type=sm), [Donga children's-fiction archive](https://sinchoon.donga.com/List?c=0109&m=part), the KB collection above, and [개똥이네 sample issues](https://gaeddong.boribook.com/sample_preview). A [National Institute of Ecology collection description](https://www.nie.re.kr/nie/bbs/BMSR00042/view.do?boardId=695968116&menuNo=200054) was inspected as publication information, not complete story text.

### Optional folklore mechanisms

- [도깨비감투](https://encykorea.aks.ac.kr/Article/E0015528): a convenient concealing power has a materially visible flaw. Develop a different desire, trace, and consequence rather than copying theft, patch, and discovery in the same order.
- [팥죽할멈과 호랑이](https://folkency.nfm.go.kr/topic/detail/6002?keyword=%ED%8C%A5%EC%A3%BD&pageType=search): previously encountered small helpers contribute different established properties. Earlier access supported the official indexed definition/outline, not detailed dialogue or a particular illustrated edition.
- [방귀쟁이 설화](https://encykorea.aks.ac.kr/Article/E0021672): an inconvenient property later has a useful application. Exaggerate causal scale without assuming bodily humor is always funny to this reader.

## TV episode evidence

The prior pass compared ten episode samples and one separate official script excerpt. The [TV engines](tv-engines.md) are writing inferences from this limited set, not formulas proven across entire series.

| ID / title | Inspected medium and scope | Supported distinction |
|---|---|---|
| G1, Grizzy: *Soins intensifs / Intensive Care*, video label Episode 124 | [Official HARI short](https://www.youtube.com/watch?v=MxaDJidGskc), 7:02; description and 84 frames at five-second intervals across the short | Care and a later caregiver/cared-for reversal vary the conflict. Not a continuous sound/gesture-timing analysis or a medical model. |
| G2, Grizzy: *Jeu de l'ours / Bear Game*, video label Episode 71 | [Official HARI short](https://www.youtube.com/watch?v=Yscf0XivaLo), 7:10; description and 86 five-second samples | A small sign/rule predicts a larger consequence; changed scale alters competition. All dice results and exact moves were not reconstructed. |
| C1, Hello Carbot S1: 바둑이를 구하라! | [Official-provider video](https://www.youtube.com/watch?v=_oIeKhx36Ls); complete public Korean transcript plus selected images | Request/summoning drives the rescue and causes a separate mistaken-car subplot. Transformation is not identical to summoning. |
| C2, Hello Carbot S1: 캠핑장에서 생긴 일 | [Official-provider video](https://www.youtube.com/watch?v=0BNqvlW5S18); complete public Korean transcript plus selected fishing images | A family day's purpose links successive smaller problems. Exact later physical action was not established by transcript alone. |
| I1, The InBESTigators: *The Case of the Curious New Girl* | [Public subtitle file](https://www.subtitlecat.com/subs/142/The%20InBESTigators%20s01e01%20Curious%20New%20Girl.eng.html), first story complete | The location of a missing container and the loss of its contents are distinct questions. First explanation is not the whole solution. |
| I2, *The Case of the Disappearing Deliveries* | Second story in the same subtitle file, complete; starts about 16:42 in the combined file | An apparently comic recurring activity also supports motive; timing and behavior can disconfirm an appealing suspect. |
| I3, *The Case of the Distracted Detective* | [ACTF official script excerpt](https://education.actf.com.au/storage/assets/2025/05/comedy-scriptwriting-resource-the-inbestigators-2.pdf), cover and two script pages, scenes 1–4 | Interrupting, apologizing, and interrupting again change the repetition. This is not whole-episode crisis/resolution evidence. |
| S1, SpongeBob: *Bubblestand* | Full indexed text of [SpongePedia fan transcript](https://en.spongepedia.org/index.php?title=Episode_Transcript%3A_Bubblestand); direct access was limited | A dismissive character joins the activity; success and pride lead to a returning material consequence. Exact performance duration unverified. |
| S2, SpongeBob: *Ripped Pants* | [Republished fan transcript PDF](https://samanthasupnet.wordpress.com/wp-content/uploads/2015/03/myfirstdoc.pdf), five pages complete, with editing traces; official clip metadata only | An initially successful joke becomes a relationship problem when repeated differently. No lyrics retained; full performance not viewed. |
| P1, PAW Patrol: *Pups Make a Splash* | First complete story in a [public transcript](https://www.springfieldspringfield.co.uk/view_episode_scripts.php?episode=s01e15&tv-show=paw-patrol-2013); official description cross-checked | An initial escape exposes a leak, requiring another capability. The package's s01e15 label differs from [Paramount+'s listing](https://www.paramountplus.com/shows/video/_lYKmpsvLTC4eAA1k0JcXvjWOPdsh0un/). |
| P2, *Pups Fall Festival* | Second complete story in the same transcript | Reorganizing movement solves a coordination failure; a character finds a useful role without a stronger machine. Whole-video acting and sound not inspected. |

Official context previously read: [HARI](https://www.studiohari.com/en/productions/grizzy-and-the-lemmings/), [Hello Carbot season archive](https://hellocarbot.choirock.com/archive/season.php?season=1), [brand description](https://choilabs.com/default/character/sub01.php), [ACTF comedy resource](https://education.actf.com.au/comedy-scriptwriting-resource), [ACTF mystery-making article](https://actf.com.au/blog/how-to-make-a-tv-mystery-the-case-of-the-inbestigators), [SpongeBob program information](https://paramountglobalcontent.com/title/spongebob-squarepants), and [PAW Patrol viewing page](https://www.pawpatrol.com/en-us/watch). These pages do not replace direct episode evidence.

## Disney production material: acting and dramatic staging

The earlier studies read the official [Animation](https://www.disneyanimation.com/process/animation/), [Hand-Drawn Animation](https://www.disneyanimation.com/process/hand-drawn-animation/), [Story](https://www.disneyanimation.com/process/story/), and [Layout](https://www.disneyanimation.com/process/layout/) pages and sampled their linked production videos. The following times belong to those files, not theatrical-film timecodes. Sampled or silent material does not establish music, exact vocal acting, every intervening movement, or the director's declared intent.

| File / recorded viewing scope | Observation and inference boundary |
|---|---|
| [Frozen II, Anna process](https://media.disneyanimation.com/media/process/FROZ2-AnnaDressProcess_BR.mp4), about 21.67 s; 12 samples from 0.15–21.52 s, including final-render 17.64–21.52 s | Torso, head angle, gaze, and hands change in interaction with Olaf. Useful for listening/intimacy design; this was not identified as a forgiveness scene. |
| [Zootopia, Manchas process](https://media.disneyanimation.com/media/process/ZOOT-ManchasProcess_BR2.mp4), about 17.31 s; 12 samples from 0.15–17.16 s; silent | Retreating partners contrast with a low approaching body. Direction, weight, and reaction support different attitudes. |
| [Moana 2, Animation 03](https://cdn.disneyanimation.com/uploads/pipeline/animation/Moana2_Process_Animation_03.mp4), 4.48 s; eight samples from 0.15–4.33 s including a black ending | Reaching, bending, hand-on-hip gesture, and a turn suggest reaction followed by a strategy/attitude change. Exact dialogue or reconciliation unverified. |
| [Raya 250 chase layout](https://media.disneyanimation.com/media/process/RAYA-250.0-editorial-2_BR.mp4), about 120.33 s; five-second overview plus 1.5-second samples from 44.5–119.5 s | Routes, obstacles, relative scale, overhead reorientation, and a change from pursuit toward confrontation. Not a cut-accurate reconstruction or confirmed bargaining dialogue. |
| [Frozen II 271 wave layout](https://media.disneyanimation.com/media/process/FROZ2_271.0_190316_1404_WR_2_BR720.mp4), about 97.38 s; overview plus one-second samples from 28.5–75.5 s | Observers and threatened place, approach, a large intercepting change, then resulting state and reactions. Scale and sequence observed; audience excitement not measured. |
| [Raya 320 storyboards](https://media.disneyanimation.com/media/process/RAYA_320_Storyboards_WEB1.mp4), about 129.08 s; overview plus one-second samples from 68–112 s | Upward reactions, a large arrival, and nearer reciprocal reactions around 98–111 s. Development material, not confirmed final-film intent. |
| [Moana WAKA 216 layout](https://media.disneyanimation.com/media/process/WAKA_216.0_160229_1719_WR2_720_BR.mp4), about 158.75 s; overview plus two-second samples from 10–54 s | Large use of body/space, a partner's response, re-establishing both, and a tattoo insert preserve differing attitudes. Lyrics were not analyzed. |

[WIR2 process](https://media.disneyanimation.com/media/process/WIR2_video_final_BR720.mp4), about 51.71 s, was surveyed but excluded as a detailed sequence case because it mainly showed the refinement of one image. Repeated production passes are not additional unique drama scenes.

## Craft and visual-understanding material previously inspected

- [Jim Zub, How I Write Comics — Part Four](https://www.jimzub.com/rambling-about-how-i-write-comics-part-four/): assigning panel information and attention. The skill's explicit “evidence” note is an adaptation, not his named universal formula.
- [Writing Excuses interview with Jim Zub](https://writingexcuses.com/writing-excuses-7-44-writing-for-comics-with-jim-zub/): page exposure and available area. Do not apply paper page-number conventions mechanically to scrolling HTML.
- Animation Mentor: [Staging](https://www.animationmentor.com/blog/staging-the-12-basic-principles-of-animation/), [Anticipation](https://www.animationmentor.com/blog/anticipation-the-12-basic-principles-of-animation/), [Exaggeration](https://www.animationmentor.com/blog/exaggeration-the-12-basic-principles-of-animation/), [Jay Jackson on dialogue](https://www.animationmentor.com/blog/some-tips-for-animating-dialogue/), and [Animating Caution](https://www.animationmentor.com/blog/tutorial-animating-caution-in-character-acting/). Read educational text; do not assume every embedded video was watched. Body/head/hands before mouth, purposeful preparation, and thought-led action informed still-panel proposals.
- [Dartmouth storyboarding PDF](https://film-media.dartmouth.edu/sites/film_media/files/department_film/wysiwyg/storyboarding.pdf): definitions and shot/angle/POV/reaction sections; [Adobe 180-degree rule](https://www.adobe.com/creativecloud/video/discover/what-is-the-180-degree-rule.html): axis and reasons to preserve or change it. A high angle's emotional effect is not automatic.
- [Kendeou et al., iLC framework](https://doi.org/10.1111/tops.12457), 2020: sections 2–3 on inference and media comparison; a theoretical/synthesis basis for the fact that pictures still require inference.
- [Klomberg & Cohn, Picture Perfect Peaks](https://doi.org/10.1017/langcog.2022.19), 2022: abstract, method, discussion. Participants were 17 or older; sound effects did not always repair an omitted event. This is not validation of these comics for eight-year-olds.

The skill's action cards, emotional transitions, and emphasis checks synthesize these materials with user feedback. They are editorial procedures; they do not establish a particular child's comprehension rate or a new story's score.
