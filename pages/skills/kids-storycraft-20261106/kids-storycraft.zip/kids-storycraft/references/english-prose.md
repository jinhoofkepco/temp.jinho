# English prose: whole-story purpose, sentence, word

These are editorial choices for new work, informed by the [English close readings](english-source-study.md) and the earlier Korean sentence study. They are not universal grammar rules or measured effects on children. The examples below are original miniature examples unless a source is explicitly identified.

## 1. Keep viewpoint inside the word choice

Separate the fact from the character's judgment. If a child mistakes a machine for a monster, the narrator need not certify it as a monster. A judgment can be clear through context without adding “she thought” to every line.

`The perfect hiding place` may introduce a character's confidence. A later drip can undo that confidence without changing what the place physically is. Choose the initial description for the later change, not just its beauty. Do not give every narrator the same breathless wonder.

## 2. Use English movement and result precisely

Choose a verb for manner or force when it matters: slide, shove, drag, wriggle, wobble, or creep do different work. Pair it with the actual route or result: under a gate, through a sleeve, out of a box, back onto a branch. A generic “went” remains useful for unimportant movement.

- Flat: `The jar moved.`
- If cause matters: `Nell nudged the jar. It slid toward the edge.`
- If the comic isolates the outcome: `The jar stopped. The spoon did not.`

Do not pack every action into a fancy verb or pile manner adverbs on top of an already exact action. For panels, make the directional phrase visible: “through” requires a passage; “off” requires separation. A noun beside an object does not prove either.

## 3. Tense, aspect, and degree change the depicted event

`He pressed the pedal`, `He was pressing it`, `He kept pressing it`, and `He tried to press it` do not mean the same thing. Continuing pressure must still have a visible source in the following panel. A failed attempt must not look completed.

Likewise, “almost,” “a little,” “still,” “again,” “already,” and “at last” require different prior conditions. “At last” needs earlier waiting or obstruction; “a little” needs a comparison; “again” needs a previous occurrence. These words are storytelling commitments, not decorations.

Keep a stable narrative tense while allowing dialogue its natural tense. Do not simplify away the time relation that makes a concealment, missed opportunity, or delayed discovery intelligible.

## 4. Place information for the English reveal

Rebuild information order rather than translating a Korean sentence ending mechanically. English can hold a result in a later clause, short sentence, balloon, or panel. Put the recognition where it is first meant to occur; do not announce the solution in the lead-in.

- Spoiled setup: `Her rabbit was in the suitcase. Bea opened it.`
- Withheld identity: `Bea opened the suitcase. Two ears popped out.`

The second version suits a particular reveal, not every scene. Name the rabbit immediately when identity is already known and the question is whether it will escape. Sentence-final emphasis is an available choice, not a rule that all new information must come last.

Choose the scope of focus words deliberately. `Only Sam could reach it` concerns the person; `Sam could reach only the handle` concerns what he reaches. Let emphasis follow the intended story question. Capitals, bold type, ellipses, and exclamation marks cannot substitute for missing preparation.

## 5. Make reference easy without making voice childish

Introduce an object clearly, then keep its identity stable: a bucket → the bucket → it, once “it” is unambiguous. Repeat a name or key noun when two similar characters or objects compete for the same pronoun. A sudden switch from “pail” to “container” may suggest a new object to a beginner.

Use ordinary English contractions where the voice calls for them. Avoid Korean-style omitted subjects when English needs an actor; purposeful dialogue fragments can remain. Keep one variety of English consistent unless a character or source has a reason to differ. An eight-year-old's interests need not be reduced to baby talk.

## 6. Repeat the pattern; change its pressure or meaning

A repeated question lets the reader anticipate its shape while a different answer alters the situation. A changed verb, response, speaker, or stressed word can carry the new information. Repetition can help language tracking and comedy at once.

Original pattern: `“One more?” “One more.”` Later, the same offer can become a worried question when the stack leans. The picture and prior action must establish why it changed. Do not force the exchange into three rounds or replace all its words to sound varied.

Read-aloud rhythm comes from stress, phrasing, repeated shapes, and pauses as well as rhyme. Do not distort word order, invent a synonym, or change a character's choice to complete a rhyme. Select English sound words for the material event; do not transliterate Korean ideophones as if they were natural English.

## 7. Let contrast do specific work

Parallel English clauses can make a changed state conspicuous: `The sign said OPEN. The door would not move.` The relation is between the promise and what the character experiences. Paired sounds, textures, or gestures can also support a larger turn.

Choose whose sensory experience matters. A warm room may feel stifling to a character longing to go outside. Avoid lists of all five senses and metaphors beyond the child's likely experience. An evocative adjective can stay when removing it changes the reader's first belief or the later contrast.

## 8. Dialogue acts on another person

Ask what each line tries to do: obtain permission, avoid discovery, recruit help, challenge an explanation, or protect pride. Let speakers differ through what they attend to and how they respond. An interrupted thought or a minimal reply may work better than a complete explanatory sentence.

- Summary: `He pretended not to care.`
- A possible action: `“Keep it,” Max said. His hand stayed on the lid.`

The hand needs a meaningful object and context; this is not a universal pose for concealed feeling. Use simple speech tags when attribution is needed. Do not replace every “said” with a dramatic synonym. When a line of dialogue is followed by an action, punctuate the action as an action rather than as a speech tag.

## 9. Let prose and image carry different needed information

A companion paragraph can add motive, time, an unspoken concern, or a distinctive voice. An illustration may hold the contradiction or clue. Do not narrate the punchline over the picture that is meant to let the reader discover it.

For an independent beginner, selective overlap between a key noun, action, and picture can be useful. For a read-aloud picture-book scene, more inference may be available. Decide the balance using [audience and language](audience-and-language.md). Never let prose alone patch a missing causal contact the comic was meant to show.

## 10. When review is requested: revise and read aloud

For a requested prose review, read the story without its craft notes. Track who acts, what changes, what the reader can infer, and which word gets the natural emphasis. Remove translation-shaped phrasing, overloaded clauses, generic emotional summaries, and explanations after an earned ending. During one-take creation, use the preceding choices while writing; do not add this finished-output revision pass automatically.

Keep intentional fragments, repeated phrases, emotion names that orient the reader, and sensory detail with a job. Shortening every sentence can flatten anticipation or make relationships harder to follow. Difficulty and dramatic simplicity are different problems.
