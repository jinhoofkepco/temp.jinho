# TV narrative engines

Use the relevant section, not every engine in each story. Retain the mechanism rather than copying an episode's distinctive sequence, catchphrase, or joke. The original study covered limited episodes and mixed kinds of evidence, summarized in [earlier evidence](earlier-evidence.md).

## Grizzy & the Lemmings: competing uses of a physical rule

A large individual wants rest, food, or control; a small group wants play. Both use the same space or property differently. One solution invites the other's counteraction and changes the temporary advantage. Elasticity, adhesion, size, weight, slope, or a device rule should be visible before its later use.

Anticipation, a confident tactic, an unexpected result, and a held reaction supply different humor beats. Cooperation or a reversal of care can vary the competition. A shared predicament does not require repentance. Two-panel work can pair a readable manipulation with the same property's unexpected consequence.

Words such as stuck, slippery, stretch, heavy, and inside fit concrete states and relations. The show is substantially nonverbal; added English balloons or captions are educational adaptations. Do not present them as original dialogue practice from the show.

## Hello Carbot: a child's request and a helper with personality

An everyday family or play problem meets a limitation, and the child chooses to summon help. The helper has pride, preferences, and irritation as well as a useful capability. Connect the decisive intervention to the child's request, observation, or judgment.

Summoning, searching, transforming, and applying a capability are different beats. A summoning can cause someone else's misunderstanding that returns at the end. A family day can link several small problems without becoming a single battle. Establish the capability a new helper will use rather than inventing it at the rescue.

For a short scene, pair a specific request with a fitting transformation or tool result. Lift, strong, rescue, stuck, and careful can be natural requests or checks; a definition lecture should not replace the actual help.

## The InBESTigators: comic observation becomes evidence and motive

A familiar anomaly prompts competing explanations, observation and questions, reinterpretation of existing facts, and an understanding of motive. Where an object went and why someone acted can be different questions; the first solved suspicion may not settle the actual loss.

Give characters different interests in the same facts. Interruptions, a boast contradicted by action, or a recurring interest can create comedy and later evidence. A retrospective explanation can differ from the image of what happened. Supply the relevant clue before the answer and allow room to infer it; a last-minute confession alone is weak participation.

Two scenes should isolate one small contradiction and its check, not many suspects and interviews. Missing, empty, same, different, clue, and behind fit observation, provided the picture proves the relevant state. Adjust language and information load for younger audiences; the series' protagonists being older does not fix the user's learner level.

## SpongeBob SquarePants: desire and personality amplify a contradiction

A wish to impress, excel, or protect a hobby meets a stubborn tactic. A small success encourages repetition, pride changes the tactic, and other people's responses turn it into a relationship or practical problem. The character takes a trivial task earnestly while the outcome grows absurd.

The surreal result still responds to the episode's premise. Confident words and inconvenient actions, or one character's beautiful creation and another's discomfort, can conflict. Pauses, indifference, and punctured pride complete reactions. A successful performance need not be the final safe state.

For two scenes, choose confidence plus a visible warning, then one disproportionate but related result. Proud, tiny, repeat, stretch, and careful can fit. Do not require a beginner to solve an unfamiliar idiom and a pun before understanding the basic event.

## PAW Patrol: a plan, differentiated roles, and visible rescue

Recognize an everyday, environmental, or mechanical problem, request help, choose roles and tools, and show their execution. Partial success can expose another condition, calling for a new capability or better coordination. Traffic flow and ordering work can solve a problem that more force cannot.

Familiar briefings and departures create anticipation but need not consume the same space each time. Let the viewer see how the chosen tool works. Establish the rescue target's safe state before a short returning character gag. A habit from play can return under different conditions during a task.

For two scenes, select a problem and fitting help request, then one exact tool use and result. Pull requires the rope's attachment and direction; leak requires the actual escaping fluid and its source. Lift, across, balance, and stuck can likewise be visible rather than merely spoken.
